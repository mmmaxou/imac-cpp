# TP 6
## Exercice 1
* Q2:
Le programme plante à l'execution à la ligne de la division par b, car b=0

## Exercice 2
* Q5:
L'instruction ```throw``` met fin à l'execution du bloc en cours et va directement à l'instruction ```catch``` liée
* Q6:
Si le bloc ```catch``` n'existe pas, le programme plante

## Exercice 3