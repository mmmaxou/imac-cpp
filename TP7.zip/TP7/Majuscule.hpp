#ifndef MAJUSCULE_IMAC_HPP__
#define MAJUSCULE_IMAC_HPP__

class Majuscule {  
  public:
    void operator()(char &c) const;
};

#endif