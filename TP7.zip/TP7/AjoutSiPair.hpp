#ifndef AJOUTSIPAIR_IMAC_HPP__
#define AJOUTSIPAIR_IMAC_HPP__

class AjoutSiPair {  
  public:
    void operator()(int &n) const;
};

#endif